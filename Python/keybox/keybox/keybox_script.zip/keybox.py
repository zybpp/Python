#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author:zhangyanbin

import os
import sys
import shutil
import re
import subprocess
import time

"""
	python keybox.py product model start end
	参数解析： 
	product 为项目名，如X705F，X705L，X705M
	model 为需要操作的keybox，如keymaster或widevine
	start 为需要操作keybox起始文件名，参数为数字，如0，1，2，3 ...（可为空，默认值为0）
	end 为需要操作keybox结束文件名，参数为数字，如0，1，2，3 ...（可为空，默认值为model目录下文件数目）
"""
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
orig_dir = BASE_DIR + "\\" + sys.argv[1] + "\\" + sys.argv[2]

def keymaster(orig_path,obj_path,deviceid):
	obj_file_path = obj_path + "\\" + deviceid + ".xml"
	shutil.copy(orig_path,obj_file_path)

def widevine(orig_path,obj_path,deviceid):
	delete_log = True
	obj_file_path = obj_path + "\\" + deviceid
	if os.path.isdir(obj_file_path):
		shutil.rmtree(obj_file_path)
	os.makedirs(obj_file_path)
	filename = "widevine_" + deviceid + ".txt"
	with open(filename, "w") as perl_file:
		perlcmd = 'perl turn.pl "{}" {}'.format(orig_path,deviceid)
		popfile = subprocess.Popen(perlcmd,stdout=perl_file,stderr=subprocess.PIPE)
		time.sleep(1)
	with open(filename, "r") as updatefile:
		for line in updatefile:
			if line.startswith("Parsing keybox data succeeds"):
				print("DeviceId 为%s的keybox.bin转换成功" %deviceid)
				shutil.move("keybox.bin", obj_file_path)
				break
		else:
			delete_log = False
			print("DeviceId 为%s的keybox.bin转换失败" % deviceid)
	if delete_log == True:
		os.unlink(filename)
	#popfile.terminate()

if os.path.isdir(orig_dir):
	deviceid = None
	obj_dir = BASE_DIR + "\\" + sys.argv[1] + "_update" + "\\" + sys.argv[2]
	if os.path.isdir(obj_dir):
		shutil.rmtree(obj_dir)
	os.makedirs(obj_dir)
	start = int(sys.argv[3]) if len(sys.argv)>3 else 0
	end = (int(sys.argv[4]) + 1) if len(sys.argv)>4 else len(os.listdir(orig_dir))
	total = 0
	for i in range(start,end):
		index = str(i).rjust(3, "0")
		if len(os.listdir(orig_dir)) > 0:
			file_name = re.sub("\d{3}\.", index + ".", os.listdir(orig_dir)[0])
			if file_name in os.listdir(orig_dir):
				orig_file_path = orig_dir + "\\" + file_name
				with open(orig_file_path, "r") as orig_file:
					for line in orig_file:
						if len(re.findall("DeviceID=\"(\w+)\"", line)) > 0:
							deviceid = re.findall("DeviceID=\"(\w+)\"", line)[0]
							break
				if sys.argv[2] == "keymaster":
					keymaster(orig_file_path,obj_dir,deviceid)
				elif sys.argv[2] == "widevine":
					widevine(orig_file_path,obj_dir,deviceid)
				total = total + 1
			else:
				print("文件：%s  不存在" %file_name)
	if len(os.listdir(obj_dir)) == total:
		print("%s 执行完成！！" %(sys.argv[2]))
else:
	print("无此项目,请重新输入，谢谢！！")
